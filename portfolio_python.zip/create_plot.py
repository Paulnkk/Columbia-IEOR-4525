import numpy as np
import matplotlib.pyplot as plt

def create_plot(p, mu, C):
    # Visualisation of portfolios and assets in a sigma-mu-coordinate system
    # (sigma is the standard deviation, mu is the expected return)
    #
    # INPUT
    #=======================================
    # p .......... matrix with portfolio weights in columns
    # mu ......... column vector with expected returns for each asset
    # C .......... variance-covariance matrix
    
    numb = np.shape(p)[1]
    sd = np.sqrt(np.diag(C))
    
    #Determine expected return and standard deviation of optimal portfolios
    rp = np.zeros(numb);
    sdp = np.zeros(numb);
    for i in range(0,numb):
        rp[i] = p[:,i]@mu;
        sdp[i] = np.sqrt(p[:,i].dot(C@p[:,i]));
    
    plt.scatter(sd,mu, label='Assests')
    plt.title('Assets and Efficient Portfolio(s)')
    plt.ylabel('expected return (annualized)')
    plt.xlabel('standard deviation')
    plt.scatter(sdp,rp, label='Efficient Portfolio(s)')
    plt.legend(loc = 4)
    plt.show()